/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.muni.fi.pb162.project.geometry;

/**
 *
 * @author pedro
 */
public class Square implements Circumcircle {
    private double length;
    private Vertex2D vertex;
    
    public Square(double length, Vertex2D leftDownC) {
        this.length = length;
        this.vertex = leftDownC;
    }
    
    public Square(Vertex2D center, double radius) {
        this.vertex = center;
        this.length = radius;
    }
    
    public double getRadius() {
        return (Math.sqrt(2)/2)*length;
    }
    
}
