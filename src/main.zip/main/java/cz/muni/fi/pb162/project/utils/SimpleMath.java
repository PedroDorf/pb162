/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.muni.fi.pb162.project.utils;
import cz.muni.fi.pb162.project.geometry.*;

/**
 *
 * @author pedro
 */
public class SimpleMath {
    public static Vertex2D minX(Vertex2D[] vertices) {
        Vertex2D min = vertices[0];
        for (int i = 0; i < vertices.length; i++) {
            if (vertices[i].getX() < min.getX()) {
                min = vertices[i];
            }
        }
        return min;
    }
    
    public static Vertex2D maxX(Vertex2D[] vertices) {
        Vertex2D max = vertices[0];
        for (int i = 0; i < vertices.length; i++) {
            if (vertices[i].getX() > max.getX()) {
                max = vertices[i];
            }
        }
        return max;
    }
    
    public static Vertex2D minY(Vertex2D[] vertices) {
        Vertex2D min = vertices[0];
        for (int i = 0; i < vertices.length; i++) {
            if (vertices[i].getY() < min.getY()) {
                min = vertices[i];
            }
        }
        return min;
    }
    
    public static Vertex2D maxY(Vertex2D[] vertices) {
        Vertex2D max = vertices[0];
        for (int i = 0; i < vertices.length; i++) {
            if (vertices[i].getY() > max.getY()) {
                max = vertices[i];
            }
        }
        return max;
    }
    
    
    
    
    
}
